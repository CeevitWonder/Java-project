import java.util.*;
import java.io.*;
import java.io.IOException;
import java.nio.*;
import java.net.*;

class FileIn{
	
	public static void main(String[] args) throws Exception{
	Random rar=new Random();
	Integer[] arr=new Integer[1000];
	for(int i=0;i<1000;i++){
		arr[i]=rar.nextInt(1001);
		System.out.println();
	} 
	for(int i=0;i<1000;i++){
		System.out.println(arr[i]);
	}
	
	String[] arr2= new String[arr.length];
	for(int i=0;i<1000;i++){
		arr2[i]=String.valueOf(arr[i]);
	}
		
	byte[][] arr3= new byte[1000][];
	for(int i=0;i<1000;i++){
		arr3[i]=arr2[i].getBytes();
		BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream("1k.txt"));
    	stream.write(arr3[i]);
		stream.flush();
		stream.close();
	}
	
}
}