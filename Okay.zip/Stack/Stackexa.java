import java.util.*;

class Stackexa{
public static void main(String[] args){
	Stack <Integer> stack = new Stack <Integer>();
	stack.push(89);
	stack.push(84);
	stack.push(87);
	stack.push(10);
	System.out.println("Stacks:"+stack);
	
	Stack<String> st= new Stack <String>();
	st.push("SHut");
	st.push("The");
	st.push("Prinking Bell");
	st.push("Off");
	st.push("with your mouth");
	System.out.println("StringStacks"+st);
	
	st.pop();
	//System.out.println("StringStacks"+st);
	
	//st.remove();
	System.out.println("StringStacks"+st);
	
	System.out.println(st.peek());
	
	Integer s=st.search("mouth");
	System.out.println(s);
	
	boolean e=st.empty();
	System.out.println(e);
		
}
	
}