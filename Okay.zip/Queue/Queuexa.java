import java.util.*;
import java.io.*;

class Queuexa{
	public static void main(String[] args) throws IOException
	{
		Queue<String> qr = new ArrayDeque<String>();
		qr.add("74");
		qr.add("84");
		qr.add("75");
		qr.add("71");
		qr.add("56");
		qr.offer("78");
		System.out.println("THe Queue "+qr);
		qr.peek();
		qr.poll();
		System.out.println("THe Queue "+qr);
		qr.peek();
		qr.poll();
		System.out.println("THe Queue "+qr);
		qr.peek();
		qr.poll();
		System.out.println("THe Queue "+qr);
		
	}
	
  }