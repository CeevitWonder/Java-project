import java.util.*;
import java.io.*;

class DFS{
	
	private int ver;
	private LinkedList <int> adj[];
	
	void DFS(int v){
		ver= v;
		adj= new LinkedList[v];
		for(int i=0;i<v;i++){
			adj[i] = new LinkedList();
		}
	}
	
	void addEdge(int v,int e){
		adj[v].add(e);
	}
	
	void dFS(int v,boolean w[]){
		w[v] = true;
		System.out.println()
		
	}
	
	
	
}